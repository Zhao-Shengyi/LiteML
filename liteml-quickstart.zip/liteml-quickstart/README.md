# LiteML 快速入门 / Quick Start

> 轻量级 HTML/PHP 模板语言 — 用缩进代替标签，让写网页像写大纲一样简单。
> A lightweight HTML/PHP template language — replace tags with indentation, write web pages like outlines.

---

## 📦 安装 / Installation

```bash
# 确保有 Python 3.8+
python3 --version

# 安装 TUI 依赖（可选，CLI 不需要）
pip3 install textual

# 验证编译器
python3 core/cli.py version
# → LiteML Compiler v0.2
```

---

## 🚀 30 秒上手 / 30-Second Quickstart

创建一个 `hello.lite`：

```lite
! html5
html
  head
    title 你好世界
  body
    h1#title.main 你好，世界！
    p 这是第一段。
    p 这是第二段。
```

编译它：

```bash
python3 core/cli.py build hello.lite -o hello.html
```

打开 `hello.html` 看看——不需要任何标签闭合，缩进就是结构。

---

## 📖 完整教程 / Full Tutorial

### 1. 核心规则 / Core Rules

**缩进 = 嵌套关系**。子标签比父标签多缩进 2 个空格：

```lite
div             ← 父标签
  p             ← 子标签（缩进 2）
    span        ← 孙标签（缩进 4）
```

**一行 = 一个标签**。无需写 `<` `>` `/`：

```
HTML: <div class="card"><p>内容</p></div>
LiteML: div.card
          p 内容
```

### 2. 基本语法 / Basic Syntax

```
标签名         → div, p, h1, a, img...
#id           → div#header
.class        → div.card.highlight
[attr=val]    → a[href=https://example.com]
文本          → 标签名后面直接跟文本：p 这是段落内容
```

完整示例：

```lite
div#container.wrapper                ← div id="container" class="wrapper"
  a[href=https://example.com][target=_blank] 点击这里
  img[src=logo.png][alt=Logo]        ← 自闭合标签自动处理
```

### 3. 特殊类型 / Special Types

**文档类型**：
```lite
! html5     → <!DOCTYPE html>
```

**HTML 注释**：
```lite
@ 这是注释     → <!-- 这是注释 -->
```

**PHP 模式**：
```bash
python3 core/cli.py build index.lite --mode=php -o index.php
```

PHP 模式下，`{{ }}` 自动转为 `<?= htmlspecialchars(...) ?>`：

```lite
p 你好，{{ $name }}！
  → <p>你好，<?php echo htmlspecialchars($name); ?>！</p>
```

### 4. 控制流 / Control Flow (PHP mode)

```lite
@if($loggedIn)
  p 欢迎回来！
@else
  p 请登录。
@endif       ← 无需手动写，编译器自动闭合

@foreach($items as $item)
  div.item {{ $item }}
```

### 5. 内置指令 / Built-in Directives

**布局指令**（标签附加）：

```lite
div@flex(center,between)              ← display:flex; align-items:center; justify-content:space-between
div@grid(cols=3,gap=20px)             ← CSS Grid，自动生成响应式
div@waterfall(cols=4,gap=16px)        ← 瀑布流布局（column-count）
div@hide(mobile)                      ← 在移动端隐藏
button@modal(open=#myDialog)          ← 点击打开 <dialog>
button@theme-toggle                   ← 暗色模式切换
div@position(fixed,top=0,left=0)      ← position:fixed; top:0; left:0
div@transition(all 0.3s ease)         ← transition: all 0.3s ease
button@like                            ← 点赞按钮（带计数）
```

**宏指令**（独立一行）：

```lite
@css(style.css)                       ← <link rel="stylesheet" href="style.css">
@js(app.js|defer)                      ← <script src="app.js" defer></script>
@audio(song.mp3|controls,loop)        ← <audio src="song.mp3" controls loop>
@video(video.mp4|autoplay,muted)       ← <video src="video.mp4" autoplay muted>
@embed(https://youtube.com/watch?v=xxx | ratio=16:9)  ← 响应式 iframe
@icon(search)                         ← <i class="icon-search"></i>
@flex(center,between)                 ← 独立的 flex 容器
```

### 6. 代码块 / Code Blocks

**CSS 块**：
```lite
@css
  body { font-family: sans-serif; }
  .dark { background: #1a1b26; }
```

**JS 块**：
```lite
@js
  console.log('Hello from LiteML!');
```

**长文本**（`"""..."""`）：
```lite
"""
这是很长的一段文字。
会自动分成段落。
"""
```

**代码展示**（```` ``` ````）：
```lite
```python
def hello():
    print("Hello!")
```
```

### 7. 组件系统 / Components (`@use`)

组件是用原生 HTML/CSS/JS 写成的独立模块，放在 `components/` 目录下：

```
components/
  ├── dark-mode-toggle/
  │   ├── component.json      ← 组件清单
  │   ├── template.html       ← 模板 HTML
  │   ├── style.css           ← 样式
  │   └── script.js           ← 脚本
  └── your-component/
```

在 `.lite` 文件中使用：

```lite
body
  h1 我的网站
  @use dark-mode-toggle
```

编译器会自动：
- 把 `template.html` 嵌入到 `@use` 位置
- 把 CSS 注入到 `<head>` 中（或通过 `--css=external` 输出到独立文件）
- 把 JS 注入到 `</body>` 前（或通过 `--js=external` 输出到独立文件）

**创建新组件**：

```bash
python3 core/cli.py components init my-button
```

### 8. @include / @eject

**@include**：插入外部 HTML 或 PHP include

```lite
@include(header.html)
@include(sidebar.php)     ← PHP 模式下转为 <?php include "sidebar.php"; ?>
```

**@eject**：内置组件的"回退"模式

```lite
button@modal!(open=#dialog)  ← @directive! 表示 eject 模式
```

### 9. 编译选项 / Build Options

```bash
# 基本用法
python3 core/cli.py build input.lite -o output.html

# 编译整个目录
python3 core/cli.py build src/ -o dist/

# PHP 模式
python3 core/cli.py build input.lite --mode=php -o output.php

# 组件 CSS/JS 输出为独立文件
python3 core/cli.py build input.lite --css=external --js=external -o output.html
# → output.html + output.components.css + output.components.js

# 监听文件变化
python3 core/cli.py watch input.lite -o output.html
```

### 10. TUI 界面 / Terminal UI

```bash
# 需要先安装 textual
pip3 install textual

# 启动
python3 core/tui.py
# 或直接打开文件
python3 core/tui.py myfile.lite
```

TUI 提供：
- 左侧文件浏览器
- 右侧代码编辑器
- 模式选择（HTML/PHP + CSS/JS 策略）
- 实时编译预览
- Ctrl+B 编译 / Ctrl+S 保存并编译

---

## 📂 完整示例 / Full Example

查看 `examples/intro.lite` — 这是一个用 LiteML 写的 LiteML 介绍页面，每段代码都附有编译后的 HTML 对照。

编译它：

```bash
python3 core/cli.py build examples/intro.lite -o examples/intro.html
```

---

## 📄 许可证 / License

MIT
